"""Adds FrameXTV as a player server in Qaisflixx (URL format from the Birch OS notes)."""
import sys
p = sys.argv[1].rstrip('/') + '/src/lib/tmdb.ts'
s = open(p).read()
head = 'export const STREAMING_SERVERS: StreamingServer[] = ['
assert head in s, 'server list not found'
line = (head + "\n  { id: 'framextv', name: 'FrameXTV', category: 'new', url: (id, type = 'movie', s, e) => "
        "type === 'tv' && s && e ? `https://framextv.cc/embed/${id}/${s}/${e}` : `https://framextv.cc/embed/${id}` },")
open(p, 'w').write(s.replace(head, line, 1))
