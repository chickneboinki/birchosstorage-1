#!/usr/bin/env bash
# Builds the real Qaisflixx and Qaisifyy apps from their repos and bundles them into the launcher's
# assets so they run fully inside Birch OS. Each app is best-effort: if one fails to build, the APK
# is still produced and that tile keeps its old website shortcut.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WWW="$HERE/../assets/www"
WORK="$(mktemp -d)"
LIST=()

bundle() { # name repo old-url
  local name="$1" repo="$2" old="$3"
  echo "::group::Bundling $name from $repo"
  if (
    set -e
    git clone --depth 1 "https://github.com/CronusAquilx/$repo.git" "$WORK/$repo"
    cd "$WORK/$repo"
    sed -i 's/BrowserRouter/HashRouter/g' src/App.tsx          # routes live after the # so the bundled files can serve them
    [ -f "$HERE/patch-$name.py" ] && python3 "$HERE/patch-$name.py" .
    npm install --no-audit --no-fund --legacy-peer-deps
    npx vite build --base=./ --outDir dist --emptyOutDir
    test -f dist/index.html
    rm -rf "$WWW/apps/$name" && mkdir -p "$WWW/apps/$name" && cp -r dist/. "$WWW/apps/$name/"
  ); then
    LIST+=("$name|$old")
    echo "Bundled $name"
  else
    echo "::warning::$name could not be bundled - keeping its website shortcut"
  fi
  echo "::endgroup::"
}

mkdir -p "$WWW/apps"
bundle qaisflixx qaisflixx "https://qaisfluxx.lovable.app"
bundle qaisifyy  qaisifyy  "https://qaisifyy.lovable.app"

json="["; sep=""
for e in "${LIST[@]:-}"; do
  [ -z "$e" ] && continue
  name="${e%%|*}"; old="${e#*|}"; new="https://birchos.local/apps/$name/index.html"
  json="$json$sep{\"old\":\"$old\",\"new\":\"$new\"}"; sep=","
  # point the launcher tile at the bundled copy
  grep -rl --include=*.js --exclude-dir=apps "$old" "$WWW" | xargs -r sed -i "s#$old#$new#g"
done
echo "$json]" > "$WWW/apps/bundled.json"
echo "bundled.json: $(cat "$WWW/apps/bundled.json")"
