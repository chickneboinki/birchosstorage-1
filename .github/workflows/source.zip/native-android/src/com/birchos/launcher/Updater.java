package com.birchos.launcher;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

/** Checks the latest GitHub release of birchosstorage and installs it over the running app. */
final class Updater {
    static final String API = "https://api.github.com/repos/CronusAquilx/birchosstorage/releases/latest";
    static final String UA = "Mozilla/5.0 (Linux; Android 11; AFTKA) BirchOS-Updater";
    static volatile boolean checking;
    static volatile boolean installing;

    static int current(android.content.Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionCode;
        } catch (Throwable t) {
            return 0;
        }
    }

    static void emit(final MainActivity a, final JSONObject o) {
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (a.web != null) {
                    a.web.evaluateJavascript("window.__birchUpdate&&window.__birchUpdate(" + o.toString() + ")", null);
                }
            }
        });
    }

    static JSONObject ev(String state) {
        JSONObject o = new JSONObject();
        try {
            o.put("state", state);
        } catch (Throwable ignored) {
        }
        return o;
    }

    static String read(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
        in.close();
        return out.toString("utf-8");
    }

    /** silent=true: launch-time check, only speaks up when an update exists. */
    static void check(final MainActivity a, final boolean silent) {
        if (checking || installing) return;
        checking = true;
        if (!silent) emit(a, ev("checking"));
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(API).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("User-Agent", UA);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    int code = c.getResponseCode();
                    if (code != 200) throw new Exception("GitHub answered " + code);
                    JSONObject j = new JSONObject(read(c.getInputStream()));
                    String digits = j.optString("tag_name", "").replaceAll("[^0-9]", "");
                    int latest = digits.length() == 0 ? 0 : Integer.parseInt(digits);
                    String url = null;
                    JSONArray assets = j.optJSONArray("assets");
                    if (assets != null) {
                        for (int i = 0; i < assets.length(); i++) {
                            JSONObject as = assets.getJSONObject(i);
                            if (as.optString("name", "").toLowerCase().endsWith(".apk")) {
                                url = as.optString("browser_download_url", null);
                                break;
                            }
                        }
                    }
                    final int cur = current(a);
                    if (url == null || latest <= cur) {
                        if (!silent) {
                            JSONObject o = ev("uptodate");
                            o.put("current", cur);
                            emit(a, o);
                        }
                    } else {
                        JSONObject o = ev("available");
                        o.put("current", cur);
                        o.put("latest", latest);
                        emit(a, o);
                        final int fl = latest;
                        final String fu = url;
                        a.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                prompt(a, cur, fl, fu);
                            }
                        });
                    }
                } catch (Throwable t) {
                    if (!silent) {
                        JSONObject o = ev("error");
                        try {
                            o.put("msg", String.valueOf(t.getMessage()));
                        } catch (Throwable ignored) {
                        }
                        emit(a, o);
                    }
                } finally {
                    checking = false;
                }
            }
        }).start();
    }

    static void prompt(final MainActivity a, int cur, int latest, final String url) {
        if (a.isFinishing()) return;
        try {
            new AlertDialog.Builder(a, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Birch OS update available")
                    .setMessage("Build " + latest + " is ready (you have build " + cur + ").\n\nBirch OS will download it, then Android asks you to confirm the install. Your settings and profiles are kept.")
                    .setPositiveButton("Update now", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            install(a, url);
                        }
                    })
                    .setNegativeButton("Later", null)
                    .show();
        } catch (Throwable ignored) {
        }
    }

    static void install(final MainActivity a, final String url) {
        if (installing) return;
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(a, "Allow Birch OS to install apps, then check for updates again", Toast.LENGTH_LONG).show();
            try {
                a.startActivity(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.parse("package:" + a.getPackageName())));
            } catch (Throwable ignored) {
            }
            return;
        }
        installing = true;
        Toast.makeText(a, "Downloading update...", Toast.LENGTH_LONG).show();
        emit(a, ev("downloading"));
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Dl.ref = null;
                    Dl.run(a, url, UA);
                    emit(a, ev("installing"));
                } catch (Throwable t) {
                    Dl.note(t);
                    a.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(a, "Update failed: " + Dl.err, Toast.LENGTH_LONG).show();
                        }
                    });
                    JSONObject o = ev("error");
                    try {
                        o.put("msg", String.valueOf(Dl.err));
                    } catch (Throwable ignored) {
                    }
                    emit(a, o);
                } finally {
                    installing = false;
                }
            }
        }).start();
    }
}
