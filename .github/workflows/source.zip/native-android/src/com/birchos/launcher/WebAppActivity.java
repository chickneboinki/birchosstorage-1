package com.birchos.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class WebAppActivity extends Activity {
    static final String[] AD_HOSTS = {"doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google", "popads.net", "popcash.net", "propellerads", "adsterra", "exoclick", "juicyads", "trafficjunky", "onclickads", "onclkds", "adcash", "hilltopads", "clickadu", "a-ads.com", "mgid.com", "taboola", "outbrain", "revcontent", "zeroredirect", "adnxs.com", "yllix", "bidgear", "acint.net", "histats", "dtscout", "pushame", "richpush", "monetag", "galaksion", "adskeeper", "ad-maven", "admaven", "pemsrv", "tsyndicate", "adspyglass", "realsrv", "magsrv", "bngpt", "crumpet", "popmyads", "ad.plus", "adtng", "clickaine", "whos.amung", "umeng", "disqusads", "aclib", "profitableratecpm", "highperformanceformat", "effectivecpmgate", "displayvertising"};
    static final String FS_CSS = "(function(){try{if(document.getElementById('birch-fs'))return;var st=document.createElement('style');st.id='birch-fs';st.textContent=':not(html):not(body):fullscreen,:not(html):not(body):-webkit-full-screen{position:fixed!important;inset:0!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;background:#000!important;transform:none!important}video:fullscreen,video:-webkit-full-screen,:fullscreen video,:-webkit-full-screen video{width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:contain!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();";
    static final String LITE = "(function(){try{if(document.getElementById('birch-lite'))return;var st=document.createElement('style');st.id='birch-lite';st.textContent='*,*::before,*::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}[class*=blur]:not(video):not(iframe){filter:none!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();";
    static final String NO_POPUPS = "(function(){try{window.open=function(){return null};document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[target=_blank]');if(a){a.removeAttribute('target')}},true);}catch(e){}})();";
    static final String SPOOF = "(function(){try{var d=Object.defineProperty,n=navigator;if(!window.chrome)window.chrome={app:{isInstalled:false},runtime:{},loadTimes:function(){return{}},csi:function(){return{}}};d(n,'webdriver',{get:function(){return false}});d(n,'vendor',{get:function(){return 'Google Inc.'}});try{delete window.Android;delete window.AndroidBridge;delete window.BirchAndroid}catch(e){}var oo=XMLHttpRequest.prototype.setRequestHeader;XMLHttpRequest.prototype.setRequestHeader=function(k,v){if(/x-requested-with/i.test(k))return;return oo.apply(this,arguments)};}catch(e){}})();";
    View chooser;
    View cursor;
    FrameLayout fsLayer;
    WebChromeClient.CustomViewCallback fullCb;
    View fullView;
    boolean hd;
    boolean hl;
    boolean hr;
    boolean hu;
    long lastFrame;
    boolean looping;
    FrameLayout root;
    int savedY;
    float vx;
    float vy;
    WebView web;
    boolean cursorMode = false;
    float cx = 400.0f;
    float cy = 300.0f;
    String homeBase = "";
    final Choreographer.FrameCallback frame = new Choreographer.FrameCallback() { // from class: com.birchos.launcher.WebAppActivity.3
        /* JADX WARN: Removed duplicated region for block: B:11:0x0073  */
        /* JADX WARN: Removed duplicated region for block: B:17:0x00fe  */
        /* JADX WARN: Removed duplicated region for block: B:22:0x0120  */
        /* JADX WARN: Removed duplicated region for block: B:27:0x0185 A[ADDED_TO_REGION] */
        /* JADX WARN: Removed duplicated region for block: B:37:0x008f  */
        @Override // android.view.Choreographer.FrameCallback
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void doFrame(long j) {
            WebAppActivity w = WebAppActivity.this;
            float dt = w.lastFrame == 0 ? 0.016f : Math.min(0.05f, ((float) (j - w.lastFrame)) / 1.0E9f);
            w.lastFrame = j;
            int dx = (w.hr ? 1 : 0) - (w.hl ? 1 : 0);
            int dy = (w.hd ? 1 : 0) - (w.hu ? 1 : 0);
            if (dx == 0) {
                w.vx -= w.vx * Math.min(1.0f, dt * 14.0f);
            } else {
                w.vx += dx * 2600.0f * dt;
                if (w.vx * dx < 260.0f) {
                    w.vx = dx * 260;
                }
            }
            if (dy == 0) {
                w.vy -= w.vy * Math.min(1.0f, dt * 14.0f);
            } else {
                w.vy += dy * 2600.0f * dt;
                if (w.vy * dy < 260.0f) {
                    w.vy = dy * 260;
                }
            }
            w.vx = Math.max(-1500.0f, Math.min(1500.0f, w.vx));
            w.vy = Math.max(-1500.0f, Math.min(1500.0f, w.vy));
            float width = w.root.getWidth();
            float height = w.root.getHeight();
            w.cx += w.vx * dt;
            w.cy += w.vy * dt;
            if (w.cy < 50.0f && w.vy < 0.0f) {
                w.web.scrollBy(0, (int) (w.vy * dt * 2.0f));
            }
            if (w.cy > height - 50.0f && w.vy > 0.0f) {
                w.web.scrollBy(0, (int) (w.vy * dt * 2.0f));
            }
            w.cx = Math.max(0.0f, Math.min(width - 1.0f, w.cx));
            w.cy = Math.max(0.0f, Math.min(height - 1.0f, w.cy));
            w.placeCursor();
            long now = SystemClock.uptimeMillis();
            MotionEvent hover = MotionEvent.obtain(now, now, 7, w.cx, w.cy, 0);
            hover.setSource(8194);
            w.web.dispatchGenericMotionEvent(hover);
            hover.recycle();
            if (dx != 0 || dy != 0 || Math.abs(w.vx) > 5.0f || Math.abs(w.vy) > 5.0f) {
                Choreographer.getInstance().postFrameCallback(this);
                return;
            }
            w.vx = 0.0f;
            w.vy = 0.0f;
            w.looping = false;
            w.lastFrame = 0L;
        }
    };

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$installApk$5$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m2lambda$installApk$5$combirchoslauncherWebAppActivity() {
        Toast.makeText(this, "Download failed: " + Dl.err, 1).show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$installApk$6$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m3lambda$installApk$6$combirchoslauncherWebAppActivity(String str, String str2) {
        try {
            if (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls()) {
                Dl.run(this, str, str2);
            } else {
                runOnUiThread(new Runnable() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda5
                    @Override // java.lang.Runnable
                    public final void run() {
                        WebAppActivity.this.m1lambda$installApk$4$combirchoslauncherWebAppActivity();
                    }
                });
            }
        } catch (Throwable th) {
            Dl.note(th);
            runOnUiThread(new Runnable() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    WebAppActivity.this.m2lambda$installApk$5$combirchoslauncherWebAppActivity();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$onCreate$0$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m4lambda$onCreate$0$combirchoslauncherWebAppActivity(String str, String str2, String str3, String str4, long j) {
        String lowerCase = URLUtil.guessFileName(str, str3, str4).toLowerCase();
        if (lowerCase.endsWith(".apk") || lowerCase.endsWith(".xapk") || lowerCase.endsWith(".apks") || lowerCase.endsWith(".apkm") || "application/vnd.android.package-archive".equals(str4) || "application/octet-stream".equals(str4)) {
            installApk(str, str2);
        } else {
            Toast.makeText(this, "Birch OS can only install app files (.apk / .xapk)", 1).show();
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        if (z) {
            hideBars(getWindow().getDecorView());
        }
    }

    void hideBars(View view) {
        view.setSystemUiVisibility(5894);
    }

    static String base(String str) {
        if (str == null) {
            return "";
        }
        String[] split = str.split("\\.");
        return split.length <= 2 ? str : split[split.length - 2] + "." + split[split.length - 1];
    }

    static boolean isAd(String str) {
        if (str == null) {
            return false;
        }
        for (String str2 : AD_HOSTS) {
            if (str.contains(str2)) {
                return true;
            }
        }
        return false;
    }

    static WebResourceResponse empty() {
        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(16779136);
        FrameLayout frameLayout = new FrameLayout(this);
        this.root = frameLayout;
        frameLayout.setBackgroundColor(0);
        WebView webView = new WebView(this);
        this.web = webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setUseWideViewPort(false);
        settings.setMixedContentMode(2);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setCacheMode(-1);
        this.web.setOverScrollMode(2);
        settings.setUserAgentString("Mozilla/5.0 (Linux; Android 11; BRAVIA 4K UR3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
        CookieManager.getInstance().setAcceptThirdPartyCookies(this.web, true);
        this.web.setBackgroundColor(0);
        this.web.setWebViewClient(new WebViewClient() { // from class: com.birchos.launcher.WebAppActivity.1
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView2, WebResourceRequest webResourceRequest) {
                Uri url = webResourceRequest.getUrl();
                String scheme = url.getScheme();
                if (!"http".equals(scheme) && !"https".equals(scheme)) {
                    return true;
                }
                if (Dl.pkgUrl(url)) {
                    WebAppActivity webAppActivity = WebAppActivity.this;
                    webAppActivity.installApk(url.toString(), webAppActivity.web.getSettings().getUserAgentString());
                    return true;
                }
                if (WebAppActivity.isAd(url.getHost())) {
                    return true;
                }
                if (!webResourceRequest.isForMainFrame() || WebAppActivity.this.homeBase.isEmpty() || WebAppActivity.this.homeBase.equals(WebAppActivity.base(url.getHost()))) {
                    return false;
                }
                String lowerCase = url.toString().toLowerCase();
                return (lowerCase.contains("apk") || lowerCase.contains("download")) ? false : true;
            }

            @Override // android.webkit.WebViewClient
            public void doUpdateVisitedHistory(WebView webView2, String str, boolean z) {
                super.doUpdateVisitedHistory(webView2, str, z);
                WebAppActivity.this.scheduleCapture();
            }

            @Override // android.webkit.WebViewClient
            public void onPageStarted(WebView webView2, String str, Bitmap bitmap) {
                webView2.evaluateJavascript(WebAppActivity.NO_POPUPS, null);
                String str2 = Pic.js;
                if (str2 != null) {
                    webView2.evaluateJavascript(str2, null);
                }
            }

            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView webView2, String str) {
                webView2.evaluateJavascript("(function(){try{window.open=function(){return null};document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[target=_blank]');if(a){a.removeAttribute('target')}},true);}catch(e){}})();(function(){try{if(document.getElementById('birch-lite'))return;var st=document.createElement('style');st.id='birch-lite';st.textContent='*,*::before,*::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}[class*=blur]:not(video):not(iframe){filter:none!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();", null);
                webView2.evaluateJavascript(WebAppActivity.FS_CSS, null);
                String str2 = Pic.js;
                if (str2 != null) {
                    webView2.evaluateJavascript(str2, null);
                }
            }

            @Override // android.webkit.WebViewClient
            public WebResourceResponse shouldInterceptRequest(WebView webView2, WebResourceRequest webResourceRequest) {
                InputStream inputStream;
                String str;
                Uri url = webResourceRequest.getUrl();
                if (MainActivity.HOST.equals(url.getHost())) {
                    return MainActivity.serve(WebAppActivity.this, url);
                }
                if (WebAppActivity.isAd(url.getHost())) {
                    return WebAppActivity.empty();
                }
                String str2 = webResourceRequest.getRequestHeaders().get("Accept");
                if ("GET".equals(webResourceRequest.getMethod()) && str2 != null) {
                    String str3 = "text/html";
                    if (!str2.contains("text/html") || webResourceRequest.isForMainFrame()) {
                        return null;
                    }
                    String host = url.getHost() == null ? "" : url.getHost();
                    if (host.contains("cloudflare") || host.contains("recaptcha") || host.contains("google.com") || host.contains("hcaptcha")) {
                        return null;
                    }
                    try {
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url.toString()).openConnection();
                        httpURLConnection.setInstanceFollowRedirects(true);
                        httpURLConnection.setConnectTimeout(10000);
                        httpURLConnection.setReadTimeout(15000);
                        for (Map.Entry<String, String> entry : webResourceRequest.getRequestHeaders().entrySet()) {
                            if (!entry.getKey().equalsIgnoreCase("X-Requested-With")) {
                                httpURLConnection.setRequestProperty(entry.getKey(), entry.getValue());
                            }
                        }
                        httpURLConnection.setRequestProperty("User-Agent", webView2.getSettings().getUserAgentString());
                        String cookie = CookieManager.getInstance().getCookie(url.toString());
                        if (cookie != null) {
                            httpURLConnection.setRequestProperty("Cookie", cookie);
                        }
                        int responseCode = httpURLConnection.getResponseCode();
                        Map<String, List<String>> headerFields = httpURLConnection.getHeaderFields();
                        HashMap hashMap = new HashMap();
                        for (Map.Entry<String, List<String>> entry2 : headerFields.entrySet()) {
                            if (entry2.getKey() != null && !entry2.getValue().isEmpty()) {
                                if (entry2.getKey().equalsIgnoreCase("Set-Cookie")) {
                                    Iterator<String> it = entry2.getValue().iterator();
                                    while (it.hasNext()) {
                                        CookieManager.getInstance().setCookie(url.toString(), it.next());
                                    }
                                } else {
                                    String lowerCase = entry2.getKey().toLowerCase();
                                    if (!lowerCase.equals("content-security-policy") && !lowerCase.equals("x-frame-options") && !lowerCase.equals("content-encoding") && !lowerCase.equals("content-length") && !lowerCase.equals("transfer-encoding")) {
                                        hashMap.put(entry2.getKey(), entry2.getValue().get(0));
                                    }
                                }
                            }
                        }
                        if (responseCode >= 300 && responseCode < 400) {
                            return null;
                        }
                        String contentType = httpURLConnection.getContentType();
                        String str4 = "utf-8";
                        if (contentType != null) {
                            String[] split = contentType.split(";");
                            str3 = split[0].trim();
                            for (String str5 : split) {
                                if (str5.trim().startsWith("charset=")) {
                                    str4 = str5.trim().substring(8);
                                }
                            }
                        }
                        String str6 = str4;
                        InputStream errorStream = responseCode >= 400 ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
                        if (errorStream == null) {
                            return null;
                        }
                        String responseMessage = httpURLConnection.getResponseMessage();
                        if (responseMessage == null || responseMessage.isEmpty()) {
                            responseMessage = "OK";
                        }
                        String str7 = responseMessage;
                        if (!str3.contains("html")) {
                            inputStream = errorStream;
                        } else {
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            byte[] bArr = new byte[16384];
                            while (true) {
                                int read = errorStream.read(bArr);
                                if (read <= 0) {
                                    break;
                                }
                                byteArrayOutputStream.write(bArr, 0, read);
                            }
                            errorStream.close();
                            String byteArrayOutputStream2 = byteArrayOutputStream.toString(str6);
                            int indexOf = byteArrayOutputStream2.toLowerCase().indexOf("<head");
                            if (indexOf >= 0) {
                                int indexOf2 = byteArrayOutputStream2.indexOf(62, indexOf) + 1;
                                str = byteArrayOutputStream2.substring(0, indexOf2) + "<script>(function(){try{var d=Object.defineProperty,n=navigator;if(!window.chrome)window.chrome={app:{isInstalled:false},runtime:{},loadTimes:function(){return{}},csi:function(){return{}}};d(n,'webdriver',{get:function(){return false}});d(n,'vendor',{get:function(){return 'Google Inc.'}});try{delete window.Android;delete window.AndroidBridge;delete window.BirchAndroid}catch(e){}var oo=XMLHttpRequest.prototype.setRequestHeader;XMLHttpRequest.prototype.setRequestHeader=function(k,v){if(/x-requested-with/i.test(k))return;return oo.apply(this,arguments)};}catch(e){}})();(function(){try{window.open=function(){return null};document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[target=_blank]');if(a){a.removeAttribute('target')}},true);}catch(e){}})();document.addEventListener('DOMContentLoaded',function(){(function(){try{if(document.getElementById('birch-lite'))return;var st=document.createElement('style');st.id='birch-lite';st.textContent='*,*::before,*::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}[class*=blur]:not(video):not(iframe){filter:none!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();(function(){try{if(document.getElementById('birch-fs'))return;var st=document.createElement('style');st.id='birch-fs';st.textContent=':not(html):not(body):fullscreen,:not(html):not(body):-webkit-full-screen{position:fixed!important;inset:0!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;background:#000!important;transform:none!important}video:fullscreen,video:-webkit-full-screen,:fullscreen video,:-webkit-full-screen video{width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:contain!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();});</script>" + byteArrayOutputStream2.substring(indexOf2);
                            } else {
                                str = "<script>(function(){try{var d=Object.defineProperty,n=navigator;if(!window.chrome)window.chrome={app:{isInstalled:false},runtime:{},loadTimes:function(){return{}},csi:function(){return{}}};d(n,'webdriver',{get:function(){return false}});d(n,'vendor',{get:function(){return 'Google Inc.'}});try{delete window.Android;delete window.AndroidBridge;delete window.BirchAndroid}catch(e){}var oo=XMLHttpRequest.prototype.setRequestHeader;XMLHttpRequest.prototype.setRequestHeader=function(k,v){if(/x-requested-with/i.test(k))return;return oo.apply(this,arguments)};}catch(e){}})();(function(){try{window.open=function(){return null};document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[target=_blank]');if(a){a.removeAttribute('target')}},true);}catch(e){}})();document.addEventListener('DOMContentLoaded',function(){(function(){try{if(document.getElementById('birch-lite'))return;var st=document.createElement('style');st.id='birch-lite';st.textContent='*,*::before,*::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}[class*=blur]:not(video):not(iframe){filter:none!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();(function(){try{if(document.getElementById('birch-fs'))return;var st=document.createElement('style');st.id='birch-fs';st.textContent=':not(html):not(body):fullscreen,:not(html):not(body):-webkit-full-screen{position:fixed!important;inset:0!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;background:#000!important;transform:none!important}video:fullscreen,video:-webkit-full-screen,:fullscreen video,:-webkit-full-screen video{width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;object-fit:contain!important}';(document.head||document.documentElement).appendChild(st);}catch(e){}})();});</script>" + byteArrayOutputStream2;
                            }
                            inputStream = new ByteArrayInputStream(str.getBytes(str6));
                        }
                        return new WebResourceResponse(str3, str6, responseCode, str7, hashMap, inputStream);
                    } catch (Throwable th) {
                        return null;
                    }
                }
                return null;
            }

            @Override // android.webkit.WebViewClient
            public void onReceivedError(WebView webView2, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
                if (webResourceRequest.isForMainFrame()) {
                    webView2.loadData("<body style='background:#000;color:#fff;font:28px sans-serif;display:flex;align-items:center;justify-content:center;height:90vh;text-align:center'>This site couldn't be reached.<br>Check your internet or try again later.</body>", "text/html", "utf-8");
                }
            }
        });
        this.web.setWebChromeClient(new WebChromeClient() { // from class: com.birchos.launcher.WebAppActivity.2
            @Override // android.webkit.WebChromeClient
            public Bitmap getDefaultVideoPoster() {
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }

            @Override // android.webkit.WebChromeClient
            public void onShowCustomView(View view, WebChromeClient.CustomViewCallback customViewCallback) {
                if (WebAppActivity.this.fullView != null) {
                    customViewCallback.onCustomViewHidden();
                    return;
                }
                WebAppActivity.this.fullView = view;
                WebAppActivity.this.fullCb = customViewCallback;
                view.setBackgroundColor(0);
                view.setPadding(0, 0, 0, 0);
                view.setFitsSystemWindows(false);
                view.setTranslationX(0.0f);
                view.setTranslationY(0.0f);
                view.setScaleX(1.0f);
                view.setScaleY(1.0f);
                WebAppActivity.this.fsLayer.addView(view, new FrameLayout.LayoutParams(-1, -1, 17));
                WebAppActivity.this.fsLayer.setVisibility(0);
                WebAppActivity.this.fsLayer.bringToFront();
                WebAppActivity.this.cursor.setVisibility(8);
                WebAppActivity webAppActivity = WebAppActivity.this;
                webAppActivity.hideBars(webAppActivity.getWindow().getDecorView());
                WebAppActivity webAppActivity2 = WebAppActivity.this;
                webAppActivity2.hideBars(webAppActivity2.root);
                WebAppActivity.this.hideBars(view);
                view.requestFocus();
                final WebAppActivity webAppActivity3 = WebAppActivity.this;
                WebView webView2 = webAppActivity3.web;
                int scrollY = webView2.getScrollY();
                webAppActivity3.savedY = scrollY;
                webView2.scrollTo(0, scrollY >> 1);
                FrameLayout frameLayout2 = webAppActivity3.fsLayer;
                frameLayout2.postDelayed(new Runnable() { // from class: com.birchos.launcher.WebAppActivity.4
                    @Override // java.lang.Runnable
                    public void run() {
                        WebAppActivity webAppActivity4 = WebAppActivity.this;
                        if (webAppActivity4.fullView != null) {
                            webAppActivity4.fsLayer.requestLayout();
                            WebView webView3 = webAppActivity4.web;
                            webView3.scrollTo(0, webAppActivity4.savedY >> 1);
                            webView3.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null);
                        }
                    }
                }, 300L);
                frameLayout2.postDelayed(new Runnable() { // from class: com.birchos.launcher.WebAppActivity.4
                    @Override // java.lang.Runnable
                    public void run() {
                        WebAppActivity webAppActivity4 = WebAppActivity.this;
                        if (webAppActivity4.fullView != null) {
                            webAppActivity4.fsLayer.requestLayout();
                            WebView webView3 = webAppActivity4.web;
                            webView3.scrollTo(0, webAppActivity4.savedY >> 1);
                            webView3.evaluateJavascript("window.dispatchEvent(new Event('resize'))", null);
                        }
                    }
                }, 1000L);
            }

            @Override // android.webkit.WebChromeClient
            public boolean onCreateWindow(WebView webView2, boolean z, boolean z2, Message message) {
                return false;
            }

            @Override // android.webkit.WebChromeClient
            public void onHideCustomView() {
                if (WebAppActivity.this.fullView != null) {
                    WebAppActivity.this.fsLayer.removeView(WebAppActivity.this.fullView);
                }
                WebAppActivity.this.fsLayer.setVisibility(8);
                WebAppActivity.this.fullView = null;
                WebAppActivity.this.fullCb = null;
                WebAppActivity.this.web.setVisibility(0);
                WebAppActivity.this.web.requestFocus();
                WebAppActivity webAppActivity = WebAppActivity.this;
                webAppActivity.web.scrollTo(0, webAppActivity.savedY);
                WebAppActivity webAppActivity2 = WebAppActivity.this;
                webAppActivity2.hideBars(webAppActivity2.root);
                if (WebAppActivity.this.cursorMode) {
                    WebAppActivity.this.cursor.setVisibility(0);
                }
            }
        });
        this.root.addView(this.web);
        this.web.setDownloadListener(new DownloadListener() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda0
            @Override // android.webkit.DownloadListener
            public final void onDownloadStart(String str, String str2, String str3, String str4, long j) {
                WebAppActivity.this.m4lambda$onCreate$0$combirchoslauncherWebAppActivity(str, str2, str3, str4, j);
            }
        });
        this.cursor = new View(this);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(-285212673);
        gradientDrawable.setStroke(4, -16777216);
        this.cursor.setBackground(gradientDrawable);
        this.cursor.setVisibility(8);
        this.root.addView(this.cursor, new FrameLayout.LayoutParams(34, 34));
        FrameLayout frameLayout2 = new FrameLayout(this);
        this.fsLayer = frameLayout2;
        frameLayout2.setBackgroundColor(0);
        this.fsLayer.setVisibility(8);
        this.root.addView(this.fsLayer, new FrameLayout.LayoutParams(-1, -1));
        setContentView(this.root);
        hideBars(this.root);
        String stringExtra = getIntent().getStringExtra("url");
        if (stringExtra != null) {
            this.homeBase = base(Uri.parse(stringExtra).getHost());
        }
        WebView webView2 = this.web;
        if (stringExtra == null) {
            stringExtra = "about:blank";
        }
        webView2.loadUrl(stringExtra);
        showChooser();
    }

    final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
    final Runnable capRun = new Runnable() {
        @Override
        public void run() {
            Watch.capture(WebAppActivity.this, WebAppActivity.this.web);
        }
    };
    final Runnable pollRun = new Runnable() {
        @Override
        public void run() {
            Watch.capture(WebAppActivity.this, WebAppActivity.this.web);
            WebAppActivity.this.h.postDelayed(this, 20000L);
        }
    };

    void scheduleCapture() {
        h.removeCallbacks(capRun);
        h.postDelayed(capRun, 2500L);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.postDelayed(pollRun, 20000L);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(pollRun);
        h.removeCallbacks(capRun);
        Watch.capture(this, this.web);
        super.onPause();
    }

    void showChooser() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setPadding(60, 50, 60, 50);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-266856416);
        gradientDrawable.setCornerRadius(36.0f);
        linearLayout.setBackground(gradientDrawable);
        TextView textView = new TextView(this);
        textView.setText("How do you want to control this app?");
        textView.setTextColor(-1);
        textView.setTextSize(24.0f);
        textView.setPadding(0, 0, 0, 30);
        linearLayout.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setGravity(17);
        Button btn = btn("Select (arrows)");
        Button btn2 = btn("Cursor (mouse)");
        btn.setOnClickListener(new View.OnClickListener() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                WebAppActivity.this.m5lambda$showChooser$1$combirchoslauncherWebAppActivity(view);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                WebAppActivity.this.m6lambda$showChooser$2$combirchoslauncherWebAppActivity(view);
            }
        });
        linearLayout2.addView(btn);
        linearLayout2.addView(btn2);
        linearLayout.addView(linearLayout2);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2, 17);
        this.chooser = linearLayout;
        this.root.addView(linearLayout, layoutParams);
        btn2.requestFocus();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$showChooser$1$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m5lambda$showChooser$1$combirchoslauncherWebAppActivity(View view) {
        pick(false);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$showChooser$2$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m6lambda$showChooser$2$combirchoslauncherWebAppActivity(View view) {
        pick(true);
    }

    Button btn(String str) {
        Button button = new Button(this);
        button.setText(str);
        button.setAllCaps(false);
        button.setTextSize(20.0f);
        button.setTextColor(-1);
        button.setPadding(40, 24, 40, 24);
        button.setFocusable(true);
        button.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                WebAppActivity.lambda$btn$3(view, z);
            }
        });
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(24.0f);
        gradientDrawable.setColor(872415231);
        button.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(16, 0, 16, 0);
        button.setLayoutParams(layoutParams);
        return button;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$btn$3(View view, boolean z) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(24.0f);
        gradientDrawable.setColor(z ? -1 : 872415231);
        view.setBackground(gradientDrawable);
        ((Button) view).setTextColor(z ? -16777216 : -1);
    }

    void pick(boolean z) {
        this.cursorMode = z;
        this.root.removeView(this.chooser);
        this.chooser = null;
        if (z) {
            this.cx = this.root.getWidth() / 2.0f;
            this.cy = this.root.getHeight() / 2.0f;
            this.cursor.setVisibility(0);
            placeCursor();
        }
        this.web.requestFocus();
    }

    void placeCursor() {
        this.cursor.setTranslationX(this.cx - 17.0f);
        this.cursor.setTranslationY(this.cy - 17.0f);
    }

    void kick() {
        if (this.looping) {
            return;
        }
        this.looping = true;
        this.lastFrame = 0L;
        Choreographer.getInstance().postFrameCallback(this.frame);
    }

    void tap() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, this.cx, this.cy, 0);
        MotionEvent obtain2 = MotionEvent.obtain(uptimeMillis, uptimeMillis + 60, 1, this.cx, this.cy, 0);
        obtain.setSource(4098);
        obtain2.setSource(4098);
        this.web.dispatchTouchEvent(obtain);
        this.web.dispatchTouchEvent(obtain2);
        obtain.recycle();
        obtain2.recycle();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (this.chooser != null || !this.cursorMode || this.fullView != null) {
            return super.dispatchKeyEvent(keyEvent);
        }
        int keyCode = keyEvent.getKeyCode();
        boolean z = keyCode == 19 || keyCode == 20 || keyCode == 21 || keyCode == 22;
        boolean z2 = keyCode == 23 || keyCode == 66;
        if (!z && !z2) {
            return super.dispatchKeyEvent(keyEvent);
        }
        boolean z3 = keyEvent.getAction() == 0;
        if (z2) {
            if (z3 && keyEvent.getRepeatCount() == 0) {
                tap();
            }
            return true;
        }
        if (keyCode == 21) {
            this.hl = z3;
        }
        if (keyCode == 22) {
            this.hr = z3;
        }
        if (keyCode == 19) {
            this.hu = z3;
        }
        if (keyCode == 20) {
            this.hd = z3;
        }
        if (z3) {
            kick();
        }
        return true;
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.chooser != null) {
            pick(false);
            return;
        }
        if (this.fullView != null) {
            WebChromeClient.CustomViewCallback customViewCallback = this.fullCb;
            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                return;
            }
            return;
        }
        if (this.web.canGoBack()) {
            this.web.goBack();
        } else {
            finish();
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 82) {
            return super.onKeyDown(i, keyEvent);
        }
        finish();
        return true;
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        this.web.destroy();
        super.onDestroy();
    }

    void installApk(final String str, final String str2) {
        Dl.ref = this.web.getUrl();
        Toast.makeText(this, "Downloading app...", 1).show();
        new Thread(new Runnable() { // from class: com.birchos.launcher.WebAppActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                WebAppActivity.this.m3lambda$installApk$6$combirchoslauncherWebAppActivity(str, str2);
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: lambda$installApk$4$com-birchos-launcher-WebAppActivity, reason: not valid java name */
    public /* synthetic */ void m1lambda$installApk$4$combirchoslauncherWebAppActivity() {
        Toast.makeText(this, "Allow Birch OS to install apps, then try again", 1).show();
        startActivity(new Intent("android.settings.MANAGE_UNKNOWN_APP_SOURCES", Uri.parse("package:" + getPackageName())));
    }
}
