package com.birchos.launcher;

import android.net.Uri;
import android.webkit.WebResourceResponse;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: classes.dex */
public class Prox {
    public static boolean allowed(String str) {
        return str != null && ("f-droid.org".equals(str) || str.endsWith(".aptoide.com") || str.endsWith(".github.com") || str.endsWith(".f-droid.org"));
    }

    public static WebResourceResponse handle(Uri uri) {
        if (!"/__p".equals(uri.getPath())) {
            return null;
        }
        try {
            String queryParameter = uri.getQueryParameter("u");
            if (queryParameter != null && queryParameter.startsWith("https://") && allowed(Uri.parse(queryParameter).getHost())) {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(queryParameter).openConnection();
                httpURLConnection.setConnectTimeout(15000);
                httpURLConnection.setReadTimeout(15000);
                httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11; AFTKA) BirchOS");
                httpURLConnection.setRequestProperty("Accept", "application/json");
                if (httpURLConnection.getResponseCode() < 400) {
                    return new WebResourceResponse("application/json", "utf-8", httpURLConnection.getInputStream());
                }
            }
        } catch (Throwable unused) {
        }
        return null;
    }
}
