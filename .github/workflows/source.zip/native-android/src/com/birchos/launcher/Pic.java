package com.birchos.launcher;

/* loaded from: classes.dex */
public class Pic {
    public static volatile String js;
}
