package com.birchos.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * "Continue watching": remembers the exact page (show / season / episode) the person was on inside
 * the movie and anime sites. MainActivity hands the list to the launcher web UI, whose existing
 * Continue watching row reopens the saved URL.
 */
final class Watch {
    static final String PREF = "birch";
    static final String KEY = "watch";
    static final Pattern HINT = Pattern.compile("(?i)(watch|episode|[/_-]ep[-_]?\\d|season|[/_-]s\\d+e\\d+|/play|stream|/movie|/tv/|/series|/anime|/embed)");
    static final Pattern NOT = Pattern.compile("(?i)(search|login|signin|signup|register|account|profile|settings|genre|category|/browse|/home/?$)");
    static final Pattern SE = Pattern.compile("(?i)\\bs(?:eason)?[-_ /=]?(\\d{1,2})[-_ /.&=]*e(?:p|pisode)?[-_ /=]?(\\d{1,3})");
    static final Pattern EP = Pattern.compile("(?i)(?:\\bep|episode)[-_ =/]?(\\d{1,4})");
    static final Pattern SEASON = Pattern.compile("(?i)season[-_ =/]?(\\d{1,2})");
    static final String JS = "(function(){var m=document.querySelector('meta[property=\"og:image\"]');var v=document.querySelector('video');var h=document.querySelector('h1');"
            + "return JSON.stringify({img:(m&&m.content)||'',t:(v&&isFinite(v.currentTime))?v.currentTime:0,d:(v&&isFinite(v.duration))?v.duration:0,h:h?(h.textContent||'').trim().slice(0,80):''})})()";

    static boolean trackable(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url);
        String scheme = u.getScheme();
        if (!"http".equals(scheme) && !"https".equals(scheme)) return false;
        String host = u.getHost() == null ? "" : u.getHost();
        if (MainActivity.HOST.equals(host)) {
            String f = u.getFragment() == null ? "" : u.getFragment();
            return (u.getPath() != null && u.getPath().startsWith("/apps/qaisflixx/")) && f.startsWith("/watch/");
        }
        if (WebAppActivity.isAd(host)) return false;
        String pq = (u.getPath() == null ? "" : u.getPath()) + (u.getQuery() == null ? "" : "?" + u.getQuery());
        return pq.length() > 1 && HINT.matcher(pq).find() && !NOT.matcher(pq).find();
    }

    static String clean(String t) {
        if (t == null) return "";
        t = t.trim();
        String[] seps = {" - ", " | ", " \u2013 ", " \u2014 ", " \u2022 "};
        for (String s : seps) {
            int i = t.indexOf(s);
            if (i > 3) t = t.substring(0, i);
        }
        t = t.replaceAll("(?i)\\b(watch|online|free|full movie|hd)\\b", " ").replaceAll("\\s+", " ").trim();
        return t.length() > 80 ? t.substring(0, 80) : t;
    }

    static String baseTitle(String t) {
        return t.replaceAll("(?i)\\b(s\\d+\\s*e\\d+|season\\s*\\d+|episode\\s*\\d+|ep\\.?\\s*\\d+)\\b", "").replaceAll("\\s+", " ").trim().toLowerCase();
    }

    static String fmt(double sec) {
        int s = (int) sec;
        int h = s / 3600, m = (s % 3600) / 60, r = s % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, r) : String.format("%d:%02d", m, r);
    }

    static JSONArray load(Context c) {
        try {
            return new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]"));
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    /** Reads the current page of a WebAppActivity WebView and stores it. Must run on the UI thread. */
    static void capture(final Context ctx, final WebView v) {
        if (v == null) return;
        final String url = v.getUrl();
        if (!trackable(url)) return;
        final String docTitle = v.getTitle();
        v.evaluateJavascript(JS, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                try {
                    String img = "";
                    double t = 0, d = 0;
                    String h = "";
                    if (value != null && !value.equals("null")) {
                        Object o = new JSONTokener(value).nextValue();
                        if (o instanceof String) {
                            JSONObject j = new JSONObject((String) o);
                            img = j.optString("img", "");
                            t = j.optDouble("t", 0);
                            d = j.optDouble("d", 0);
                            h = j.optString("h", "");
                        }
                    }
                    save(ctx, url, docTitle, h, img, t, d);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    static synchronized void save(Context ctx, String url, String docTitle, String h1, String img, double t, double d) throws Exception {
        Uri u = Uri.parse(url);
        String host = u.getHost() == null ? "" : u.getHost().replaceFirst("^www\\.", "");
        boolean bundled = MainActivity.HOST.equals(u.getHost());
        String title = bundled && h1.length() > 0 ? clean(h1) : clean(docTitle);
        if (title.length() == 0) title = clean(h1);
        if (title.length() == 0) title = host;
        String key;
        if (bundled) {
            String f = u.getFragment() == null ? "" : u.getFragment();
            int q = f.indexOf('?');
            key = "qaisflixx|" + (q >= 0 ? f.substring(0, q) : f);
        } else {
            key = host + "|" + baseTitle(title);
        }
        String all = url + " " + (docTitle == null ? "" : docTitle);
        String se = "";
        Matcher m = SE.matcher(all);
        if (m.find()) {
            se = "S" + Integer.parseInt(m.group(1)) + " E" + Integer.parseInt(m.group(2));
        } else {
            Matcher e = EP.matcher(all);
            Matcher s = SEASON.matcher(all);
            if (s.find()) se = "S" + Integer.parseInt(s.group(1));
            if (e.find()) se = (se.length() > 0 ? se + " " : "") + "E" + Integer.parseInt(e.group(1));
        }
        StringBuilder meta = new StringBuilder();
        meta.append(bundled ? "Qaisflixx" : host);
        if (se.length() > 0) meta.insert(0, se + " \u2022 ");
        if (t > 30 && d > 0 && t < d - 30) meta.append(" \u2022 ").append(fmt(t)).append(" in");
        JSONObject e = new JSONObject();
        e.put("title", title);
        e.put("img", img != null && img.startsWith("http") ? img : "");
        e.put("url", url);
        e.put("meta", meta.toString());
        e.put("key", key);
        e.put("t", System.currentTimeMillis());
        JSONArray old = load(ctx);
        JSONArray out = new JSONArray();
        out.put(e);
        for (int i = 0; i < old.length() && out.length() < 20; i++) {
            JSONObject o = old.getJSONObject(i);
            if (!key.equals(o.optString("key")) && !url.equals(o.optString("url"))) out.put(o);
        }
        SharedPreferences.Editor ed = ctx.getSharedPreferences(PREF, 0).edit();
        ed.putString(KEY, out.toString());
        ed.apply();
    }

    static void syncTo(WebView web, Context ctx) {
        if (web == null) return;
        web.evaluateJavascript("window.__birchWatchSync&&window.__birchWatchSync(" + load(ctx).toString() + ")", null);
    }
}
