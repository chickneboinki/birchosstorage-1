package com.birchos.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/* loaded from: classes.dex */
public class InstallReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        int intExtra = intent.getIntExtra("android.content.pm.extra.STATUS", -999);
        if (intExtra != -1) {
            if (intExtra == 0) {
                Toast.makeText(context, "App installed", 1).show();
                return;
            } else {
                Toast.makeText(context, "Install failed", 1).show();
                return;
            }
        }
        Intent intent2 = (Intent) intent.getParcelableExtra("android.intent.extra.INTENT");
        if (intent2 != null) {
            intent2.addFlags(268435456);
            context.startActivity(intent2);
        }
    }
}
