package com.birchos.launcher;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/* loaded from: classes.dex */
public final class Dl {
    static String err;
    static String hdr;
    static String ref;

    static void copy(InputStream inputStream, OutputStream outputStream) throws Exception {
        byte[] bArr = new byte[65536];
        while (true) {
            int read = inputStream.read(bArr);
            if (read <= 0) {
                return;
            } else {
                outputStream.write(bArr, 0, read);
            }
        }
    }

    static void fetch(String str, String str2, File file, String str3) throws Exception {
        int i = 0;
        StringBuilder sb = new StringBuilder();
        do {
            int try1 = try1(str, str2, file, i, str3);
            if (try1 == 200) {
                return;
            }
            sb.append(try1);
            sb.append(",");
            i++;
        } while (i < 4);
        sb.append(" host=");
        sb.append(Uri.parse(str).getHost());
        sb.append(" server=");
        sb.append(hdr);
        throw new IOException(sb.toString());
    }

    static void install(Context context, File file) throws Exception {
        ZipFile zipFile = new ZipFile(file);
        PackageInstaller packageInstaller = context.getPackageManager().getPackageInstaller();
        int createSession = packageInstaller.createSession(new PackageInstaller.SessionParams(1));
        PackageInstaller.Session openSession = packageInstaller.openSession(createSession);
        if (zipFile.getEntry("AndroidManifest.xml") != null) {
            FileInputStream fileInputStream = new FileInputStream(file);
            put(openSession, "app.apk", fileInputStream);
            fileInputStream.close();
        } else {
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            int i = 0;
            while (entries.hasMoreElements()) {
                ZipEntry nextElement = entries.nextElement();
                String name = nextElement.getName();
                if (name.toLowerCase().endsWith(".apk")) {
                    String replace = name.replace("/", "_");
                    InputStream inputStream = zipFile.getInputStream(nextElement);
                    put(openSession, replace, inputStream);
                    inputStream.close();
                    i++;
                }
            }
            if (i == 0) {
                throw new IOException();
            }
        }
        zipFile.close();
        openSession.commit(PendingIntent.getBroadcast(context, createSession, new Intent(context, (Class<?>) InstallReceiver.class), (Build.VERSION.SDK_INT >= 31 ? 33554432 : 0) | 134217728).getIntentSender());
        openSession.close();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void note(Throwable th) {
        String str = th.getClass().getSimpleName() + ": " + th.getMessage();
        err = str;
        Log.e("BirchDl", str);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean pkgUrl(Uri uri) {
        String path = uri.getPath();
        if (path == null) {
            return false;
        }
        String lowerCase = path.toLowerCase();
        return lowerCase.endsWith(".apk") || lowerCase.endsWith(".xapk") || lowerCase.endsWith(".apks") || lowerCase.endsWith(".apkm") || lowerCase.startsWith("/b/apk/") || lowerCase.startsWith("/b/xapk/");
    }

    static void put(PackageInstaller.Session session, String str, InputStream inputStream) throws Exception {
        OutputStream openWrite = session.openWrite(str, 0L, -1L);
        copy(inputStream, openWrite);
        session.fsync(openWrite);
        openWrite.close();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void run(Context context, String str, String str2) throws Exception {
        File file = new File(context.getCacheDir(), "dl.pkg");
        fetch(str, str2, file, ref);
        install(context, file);
        file.delete();
    }

    static int try1(String str, String str2, File file, int i, String str3) throws Exception {
        String cookie;
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
        httpURLConnection.setInstanceFollowRedirects(true);
        httpURLConnection.setConnectTimeout(30000);
        httpURLConnection.setReadTimeout(30000);
        if (i < 3) {
            httpURLConnection.setRequestProperty("User-Agent", str2);
        }
        if (i == 0 && (cookie = CookieManager.getInstance().getCookie(str)) != null) {
            httpURLConnection.setRequestProperty("Cookie", cookie);
        }
        if (i < 2 && str3 != null) {
            httpURLConnection.setRequestProperty("Referer", str3);
        }
        httpURLConnection.setRequestProperty("Accept", "*/*");
        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode != 200) {
            hdr = httpURLConnection.getHeaderField("Server");
            return responseCode;
        }
        String contentType = httpURLConnection.getContentType();
        if (contentType != null && contentType.toLowerCase().contains("text/html")) {
            throw new IOException("link gave a web page, not an app file");
        }
        InputStream inputStream = httpURLConnection.getInputStream();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        copy(inputStream, fileOutputStream);
        fileOutputStream.close();
        inputStream.close();
        return responseCode;
    }
}
