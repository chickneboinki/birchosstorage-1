package com.birchos.launcher;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.birchos.launcher.MainActivity;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class MainActivity extends Activity {
    static final String HOST = "birchos.local";
    static final String URL = "https://birchos.local/index.html";
    final Map<String, String> iconCache = new HashMap();
    WebView web;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        // Keep the Fire TV system screensaver from covering Birch's own screensaver.
        if (getSharedPreferences("birch", 0).getBoolean("keepAwake", true)) {
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        WebView webView = new WebView(this);
        this.web = webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        this.web.setBackgroundColor(-16777216);
        this.web.setWebViewClient(new WebViewClient() { // from class: com.birchos.launcher.MainActivity.1
            @Override // android.webkit.WebViewClient
            public WebResourceResponse shouldInterceptRequest(WebView webView2, WebResourceRequest webResourceRequest) {
                Uri url = webResourceRequest.getUrl();
                if (!MainActivity.HOST.equals(url.getHost())) {
                    return null;
                }
                WebResourceResponse handle = Prox.handle(url);
                if (handle != null) {
                    return handle;
                }
                String path = (url.getPath() == null || url.getPath().equals("/")) ? "/index.html" : url.getPath();
                try {
                    return new WebResourceResponse(MainActivity.mime(path), null, MainActivity.this.getAssets().open("www" + path));
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, null);
                }
            }
        });
        this.web.addJavascriptInterface(new Bridge(), "BirchAndroid");
        this.web.setSystemUiVisibility(4102);
        setContentView(this.web);
        this.web.loadUrl(URL);
        // Quiet update check a few seconds after launch; only speaks up if a newer build exists.
        this.web.postDelayed(new Runnable() {
            @Override
            public void run() {
                Updater.check(MainActivity.this, true);
            }
        }, 8000L);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Watch.syncTo(this.web, this);
    }

    /** Serves bundled files (launcher UI and the bundled apps) for https://birchos.local/... */
    static WebResourceResponse serve(android.content.Context c, Uri url) {
        WebResourceResponse handle = Prox.handle(url);
        if (handle != null) {
            return handle;
        }
        String path = (url.getPath() == null || url.getPath().equals("/")) ? "/index.html" : url.getPath();
        if (path.endsWith("/")) {
            path = path + "index.html";
        }
        try {
            return new WebResourceResponse(mime(path), null, c.getAssets().open("www" + path));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, null);
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.web.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))", null);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i == 82) {
            this.web.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'ContextMenu'}))", null);
            return true;
        }
        if (i != 85 && i != 126 && i != 127) {
            return super.onKeyDown(i, keyEvent);
        }
        this.web.evaluateJavascript("window.__studio&&window.__studio.toggle()", null);
        return true;
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.web.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))", null);
    }

    static String mime(String str) {
        if (str.endsWith(".html")) {
            return "text/html";
        }
        if (str.endsWith(".js")) {
            return "application/javascript";
        }
        if (str.endsWith(".css")) {
            return "text/css";
        }
        if (str.endsWith(".jpg") || str.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        return str.endsWith(".png") ? "image/png" : str.endsWith(".svg") ? "image/svg+xml" : str.endsWith(".woff2") ? "font/woff2" : str.endsWith(".woff") ? "font/woff"
                : str.endsWith(".json") || str.endsWith(".webmanifest") ? "application/json" : str.endsWith(".webp") ? "image/webp" : str.endsWith(".gif") ? "image/gif"
                : str.endsWith(".ico") ? "image/x-icon" : str.endsWith(".txt") ? "text/plain" : str.endsWith(".mp4") ? "video/mp4" : str.endsWith(".mp3") ? "audio/mpeg"
                : str.endsWith(".wasm") ? "application/wasm" : str.endsWith(".map") ? "application/json" : "application/octet-stream";
    }

    String iconFor(String str, Drawable drawable) {
        String str2;
        String str3 = this.iconCache.get(str);
        if (str3 != null) {
            return str3;
        }
        try {
            int max = Math.max(1, Math.min(320, drawable.getIntrinsicWidth() > 0 ? drawable.getIntrinsicWidth() : 192));
            int max2 = Math.max(1, Math.min(180, drawable.getIntrinsicHeight() > 0 ? drawable.getIntrinsicHeight() : 192));
            Bitmap createBitmap = Bitmap.createBitmap(max, max2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            drawable.setBounds(0, 0, max, max2);
            drawable.draw(canvas);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            createBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            str2 = "data:image/png;base64," + Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
        } catch (Throwable th) {
            str2 = "";
        }
        this.iconCache.put(str, str2);
        return str2;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class Bridge {
        @JavascriptInterface
        public void setPicture(String str) {
            Pic.js = str;
        }

        Bridge() {
        }

        @JavascriptInterface
        public String getInstalledApps() {
            PackageManager pm = MainActivity.this.getPackageManager();
            JSONArray arr = new JSONArray();
            HashSet<String> seen = new HashSet<String>();
            String[] cats = {"android.intent.category.LEANBACK_LAUNCHER", "android.intent.category.LAUNCHER"};
            for (String cat : cats) {
                for (ResolveInfo ri : pm.queryIntentActivities(new Intent("android.intent.action.MAIN").addCategory(cat), 0)) {
                    String pkg = ri.activityInfo.packageName;
                    if (pkg.equals(MainActivity.this.getPackageName()) || !seen.add(pkg)) {
                        continue;
                    }
                    try {
                        ApplicationInfo ai = ri.activityInfo.applicationInfo;
                        Drawable banner = cat.equals("android.intent.category.LEANBACK_LAUNCHER") ? pm.getApplicationBanner(ai) : null;
                        Drawable icon = banner != null ? banner : ri.loadIcon(pm);
                        JSONObject o = new JSONObject();
                        o.put("id", pkg);
                        o.put("name", ri.loadLabel(pm).toString());
                        o.put("icon", MainActivity.this.iconFor(pkg, icon));
                        o.put("banner", banner != null);
                        o.put("system", (ai.flags & 1) != 0);
                        int c = Build.VERSION.SDK_INT >= 26 ? ai.category : -1;
                        o.put("category", c == 0 ? "Games" : c == 1 ? "Music" : c == 2 ? "Streaming" : "Other");
                        arr.put(o);
                    } catch (Throwable ignored) {
                    }
                }
            }
            return arr.toString();
        }

        @JavascriptInterface
        public boolean launchApp(String str) {
            PackageManager packageManager = MainActivity.this.getPackageManager();
            Intent lb0 = packageManager.getLeanbackLaunchIntentForPackage(str);
            if (lb0 == null) {
                lb0 = packageManager.getLaunchIntentForPackage(str);
            }
            final Intent leanbackLaunchIntentForPackage = lb0;
            if (leanbackLaunchIntentForPackage == null) {
                return false;
            }
            leanbackLaunchIntentForPackage.addFlags(270532608);
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.birchos.launcher.MainActivity$Bridge$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.Bridge.this.m0lambda$launchApp$0$combirchoslauncherMainActivity$Bridge(leanbackLaunchIntentForPackage);
                }
            });
            return true;
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        /* renamed from: lambda$launchApp$0$com-birchos-launcher-MainActivity$Bridge, reason: not valid java name */
        public /* synthetic */ void m0lambda$launchApp$0$combirchoslauncherMainActivity$Bridge(Intent intent) {
            try {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(intent, ActivityOptions.makeCustomAnimation(mainActivity, 0, 0).toBundle());
            } catch (Throwable th) {
                MainActivity.this.startActivity(intent);
            }
        }

        @JavascriptInterface
        public void openStore(String str) {
            String[] strArr = {"amzn://apps/android?p=" + str, "market://details?id=" + str, "https://www.amazon.com/gp/mas/dl/android?p=" + str};
            for (int i = 0; i < 3; i++) {
                try {
                    MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(strArr[i])).addFlags(268435456));
                    return;
                } catch (Throwable th) {
                }
            }
        }

        @JavascriptInterface
        public boolean openSystemSettings(String str) {
            String str2;
            if ("wifi".equals(str)) {
                str2 = "android.settings.WIFI_SETTINGS";
            } else if ("bluetooth".equals(str)) {
                str2 = "android.settings.BLUETOOTH_SETTINGS";
            } else if ("display".equals(str)) {
                str2 = "android.settings.DISPLAY_SETTINGS";
            } else {
                str2 = "audio".equals(str) ? "android.settings.SOUND_SETTINGS" : "android.settings.SETTINGS";
            }
            try {
                MainActivity.this.startActivity(new Intent(str2).addFlags(268435456));
                return true;
            } catch (Throwable th) {
                try {
                    MainActivity.this.startActivity(new Intent("android.settings.SETTINGS").addFlags(268435456));
                    return true;
                } catch (Throwable th2) {
                    return false;
                }
            }
        }

        @JavascriptInterface
        public void openAppInfo(String str) {
            MainActivity.this.startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + str)).addFlags(268435456));
        }

        @JavascriptInterface
        public void uninstall(String str) {
            MainActivity.this.startActivity(new Intent("android.intent.action.DELETE", Uri.parse("package:" + str)).addFlags(268435456));
        }

        @JavascriptInterface
        public void openWebApp(String str) {
            MainActivity.this.startActivity(new Intent(MainActivity.this, (Class<?>) WebAppActivity.class).putExtra("url", str));
        }

        @JavascriptInterface
        public void setKeepAwake(final boolean on) {
            MainActivity.this.getSharedPreferences("birch", 0).edit().putBoolean("keepAwake", on).apply();
            MainActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) {
                        MainActivity.this.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        MainActivity.this.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                }
            });
        }

        @JavascriptInterface
        public int appVersionCode() {
            return Updater.current(MainActivity.this);
        }

        @JavascriptInterface
        public void checkUpdate(boolean silent) {
            Updater.check(MainActivity.this, silent);
        }

        @JavascriptInterface
        public String getWatch() {
            return Watch.load(MainActivity.this).toString();
        }

        @JavascriptInterface
        public String version() {
            return "1.0";
        }
    }
}
