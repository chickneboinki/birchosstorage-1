/* Birch OS extras: app updates, Continue watching sync, bundled-app migration. */
(function () {
  'use strict';
  var B = window.BirchAndroid;

  /* ---- 1. Move saved shortcuts from the old website versions to the bundled apps (runs before the UI loads) ---- */
  try {
    var x = new XMLHttpRequest();
    x.open('GET', 'apps/bundled.json', false);
    x.send();
    if (x.status === 200) {
      var list = JSON.parse(x.responseText);
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i), v = localStorage.getItem(k), nv = v;
        if (typeof v !== 'string') continue;
        list.forEach(function (m) { if (nv.indexOf(m.old) > -1) nv = nv.split(m.old).join(m.new); });
        if (nv !== v) localStorage.setItem(k, nv);
      }
    }
  } catch (e) {}

  /* ---- 2. Settings > Check for updates ---- */
  var toast = null;
  window.__birchCheckUpdate = function (t) {
    toast = t;
    if (B && B.checkUpdate) B.checkUpdate(false);
    else t('Updates only work inside the Birch OS app.');
  };
  window.__birchUpdate = function (ev) {
    try { if (typeof ev === 'string') ev = JSON.parse(ev); } catch (e) { return; }
    function say(m) { if (toast) { try { toast(m); } catch (e) {} } }
    switch (ev.state) {
      case 'checking': say('Checking for updates...'); break;
      case 'uptodate': say("You're on the latest version (build " + ev.current + ')'); break;
      case 'available': say('Update available: build ' + ev.latest); break;
      case 'downloading': say('Downloading update...'); break;
      case 'installing': say('Installing - confirm on the screen'); break;
      case 'error': say("Couldn't update: " + (ev.msg || 'unknown error')); break;
    }
  };

  /* ---- 3. Continue watching: merge what the movie/anime windows recorded natively ---- */
  window.__birchWatchSync = function (list) {
    try {
      if (typeof list === 'string') list = JSON.parse(list);
      if (!list || !list.length) return;
      var K = 'birch-watch-v1', cur = [];
      try { cur = JSON.parse(localStorage.getItem(K) || '[]'); } catch (e) {}
      var keys = {}, urls = {};
      list.forEach(function (n) { if (n.key) keys[n.key] = 1; urls[n.url] = 1; });
      var kept = cur.filter(function (c) { return !(c.key && keys[c.key]) && !urls[c.url]; });
      var out = list.concat(kept).sort(function (a, b) { return (b.t || 0) - (a.t || 0); }).slice(0, 20);
      var prev = localStorage.getItem(K), next = JSON.stringify(out);
      if (prev !== next) {
        localStorage.setItem(K, next);
        window.dispatchEvent(new Event('birch-watch'));
      }
    } catch (e) {}
  };
  try { if (B && B.getWatch) window.__birchWatchSync(B.getWatch()); } catch (e) {}
})();
