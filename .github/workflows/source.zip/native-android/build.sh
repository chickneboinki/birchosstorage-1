#!/usr/bin/env bash
# Builds and signs the Birch OS launcher APK without Gradle (used by the GitHub workflow).
# Needs: Android build-tools + platform android-34 (BT, PF), JDK 17, and the signing key in
# KS / KS_PASS / KEY_ALIAS / KEY_PASS. VERSION_CODE / VERSION_NAME are set by the workflow.
set -euo pipefail
cd "$(dirname "$0")"
: "${BT:?set BT to the build-tools folder}" "${PF:?set PF to the platforms/android-34 folder}"
: "${KS:?}" "${KS_PASS:?}" "${KEY_ALIAS:?}" "${KEY_PASS:?}"
export KS_PASS KEY_PASS
JAR="$PF/android.jar"
VC="${VERSION_CODE:?}"; VN="${VERSION_NAME:-build-$VC}"
OUT="${OUT:-$PWD/../build-out}"
EXPECTED_SHA256="${EXPECTED_SHA256:-}"
rm -rf "$OUT" && mkdir -p "$OUT/classes" "$OUT/dex"
"$BT/aapt2" compile --dir res -o "$OUT/res.zip"
"$BT/aapt2" link -I "$JAR" --manifest AndroidManifest.xml -A assets -o "$OUT/base.apk" "$OUT/res.zip" \
  --auto-add-overlay --version-code "$VC" --version-name "$VN" --min-sdk-version 22 --target-sdk-version 34
javac -source 8 -target 8 -nowarn -cp "$JAR" -d "$OUT/classes" $(find src -name '*.java')
"$BT/d8" --lib "$JAR" --min-api 22 --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')
cp "$OUT/base.apk" "$OUT/unaligned.apk"
(cd "$OUT/dex" && zip -q "$OUT/unaligned.apk" classes.dex)
"$BT/zipalign" -f -p 4 "$OUT/unaligned.apk" "$OUT/aligned.apk"
"$BT/apksigner" sign --ks "$KS" --ks-pass env:KS_PASS --ks-key-alias "$KEY_ALIAS" --key-pass env:KEY_PASS \
  --out "$OUT/birchos-launcher.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify --print-certs "$OUT/birchos-launcher.apk" | tee "$OUT/certs.txt"
if [ -n "$EXPECTED_SHA256" ]; then
  got=$(grep -i "SHA-256 digest" "$OUT/certs.txt" | head -1 | awk '{print $NF}' | tr 'A-F' 'a-f')
  [ "$got" = "$EXPECTED_SHA256" ] || { echo "ERROR: signed with the wrong key ($got). Check the BIRCH_KEYSTORE_* secrets."; exit 1; }
fi
echo "Built $OUT/birchos-launcher.apk (versionCode $VC)"
